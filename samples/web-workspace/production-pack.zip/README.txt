ReVector production pack
SVG contains editable geometry and no embedded raster.
Dimensions are uncalibrated; supply known_width_mm before physical production.
Individual part files use supplied part dimensions when present; master preserves the source layout.
Review difference preview and warnings. Static Illustrator compatibility is not an Adobe application test.
