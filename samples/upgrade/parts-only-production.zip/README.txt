ReVector production pack
SVG contains editable geometry and no embedded raster.
Dimensions are uncalibrated; supply known_width_mm before physical production.
Individual part files use supplied dimensions when present. No assembled pattern is included.
Review difference preview and warnings. Static Illustrator compatibility is not an Adobe application test.
